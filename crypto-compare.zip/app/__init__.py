"""Crypto Compare application package."""
